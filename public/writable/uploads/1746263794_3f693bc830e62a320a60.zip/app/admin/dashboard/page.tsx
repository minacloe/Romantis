import type { Metadata } from "next"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Users, FileCheck, AlertTriangle, CheckCircle, Activity } from "lucide-react"

export const metadata: Metadata = {
  title: "Admin Dashboard | Corporate Permission Management",
  description: "Admin dashboard for corporate permission management",
}

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="text-gray-600 mt-2">System overview and management</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Users className="h-5 w-5 text-muted-foreground mr-2" />
              <div className="text-3xl font-bold">247</div>
            </div>
            <p className="text-sm text-muted-foreground mt-1">+12 this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Pending Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <FileCheck className="h-5 w-5 text-muted-foreground mr-2" />
              <div className="text-3xl font-bold">18</div>
            </div>
            <p className="text-sm text-muted-foreground mt-1">Requires attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Security Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <AlertTriangle className="h-5 w-5 text-amber-500 mr-2" />
              <div className="text-3xl font-bold">3</div>
            </div>
            <p className="text-sm text-muted-foreground mt-1">Unresolved issues</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">System Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
              <div className="text-xl font-bold">All Systems Operational</div>
            </div>
            <p className="text-sm text-muted-foreground mt-1">Last checked: 10 min ago</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Permission Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                  <span>John Doe - CRM System (Full Access)</span>
                </div>
                <Badge>Pending</Badge>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                  <span>Sarah Johnson - Financial Portal (Read Only)</span>
                </div>
                <Badge>Pending</Badge>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500"></div>
                  <span>Mike Smith - Document Management (Edit)</span>
                </div>
                <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-500"></div>
                  <span>Lisa Brown - Customer Database (Full Access)</span>
                </div>
                <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500"></div>
                  <span>David Wilson - HR System (Read Only)</span>
                </div>
                <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>
              </div>
            </div>

            <Button variant="outline" className="w-full mt-4">
              View All Requests
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>System Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-2">
                <Activity className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm font-medium">User permission updated</p>
                  <p className="text-xs text-muted-foreground">Sarah Johnson granted access to Financial Portal</p>
                  <p className="text-xs text-muted-foreground">10 minutes ago</p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Activity className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm font-medium">New user added</p>
                  <p className="text-xs text-muted-foreground">Alex Thompson added to Marketing department</p>
                  <p className="text-xs text-muted-foreground">1 hour ago</p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Activity className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Permission request rejected</p>
                  <p className="text-xs text-muted-foreground">
                    Lisa Brown's request for Customer Database access denied
                  </p>
                  <p className="text-xs text-muted-foreground">2 hours ago</p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Activity className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm font-medium">System update completed</p>
                  <p className="text-xs text-muted-foreground">Security patch applied to all systems</p>
                  <p className="text-xs text-muted-foreground">Yesterday at 11:30 PM</p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Activity className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm font-medium">User permission revoked</p>
                  <p className="text-xs text-muted-foreground">James Wilson's access to Financial Portal revoked</p>
                  <p className="text-xs text-muted-foreground">Yesterday at 3:15 PM</p>
                </div>
              </div>
            </div>

            <Button variant="outline" className="w-full mt-4">
              View Activity Log
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Permission Overview by Department</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">Marketing</span>
                <span className="text-sm text-muted-foreground">42 users</span>
              </div>
              <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                <div className="bg-primary h-full rounded-full" style={{ width: "65%" }}></div>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>65% with elevated access</span>
                <span>28 users</span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">Finance</span>
                <span className="text-sm text-muted-foreground">36 users</span>
              </div>
              <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                <div className="bg-primary h-full rounded-full" style={{ width: "78%" }}></div>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>78% with elevated access</span>
                <span>28 users</span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">IT</span>
                <span className="text-sm text-muted-foreground">25 users</span>
              </div>
              <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                <div className="bg-primary h-full rounded-full" style={{ width: "92%" }}></div>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>92% with elevated access</span>
                <span>23 users</span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">HR</span>
                <span className="text-sm text-muted-foreground">18 users</span>
              </div>
              <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                <div className="bg-primary h-full rounded-full" style={{ width: "45%" }}></div>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>45% with elevated access</span>
                <span>8 users</span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">Sales</span>
                <span className="text-sm text-muted-foreground">53 users</span>
              </div>
              <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                <div className="bg-primary h-full rounded-full" style={{ width: "58%" }}></div>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>58% with elevated access</span>
                <span>31 users</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

