import type React from "react"
import MyAdminLayout from "@/components/admin-layout"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <MyAdminLayout>{children}</MyAdminLayout>
}

