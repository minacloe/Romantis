import type { Metadata } from "next"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Filter, Download, Calendar, Eye, ChevronLeft, ChevronRight } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export const metadata: Metadata = {
  title: "Audit Logs | Corporate Permission Management",
  description: "View and analyze system audit logs",
}

export default function AuditLogs() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Audit Logs</h1>
          <p className="text-gray-600 mt-2">View permission changes and access history</p>
        </div>
        <Button variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export Logs
        </Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4 justify-between mb-6">
            <div className="flex flex-1 max-w-md items-center space-x-2">
              <Input
                type="search"
                placeholder="Search logs..."
                className="w-full"
                prefix={<Search className="h-4 w-4 text-muted-foreground" />}
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <div className="flex items-center space-x-2">
                <Select defaultValue="all">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Event Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Events</SelectItem>
                    <SelectItem value="login">Login Events</SelectItem>
                    <SelectItem value="permission">Permission Changes</SelectItem>
                    <SelectItem value="user">User Management</SelectItem>
                    <SelectItem value="system">System Changes</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2">
                <Button variant="outline" size="icon">
                  <Calendar className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon">
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Event Type</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>IP Address</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>Mar 7, 2025 08:32:15</TableCell>
                  <TableCell>admin@company.com</TableCell>
                  <TableCell>
                    <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Permission Change</Badge>
                  </TableCell>
                  <TableCell>Granted CRM access to John Doe</TableCell>
                  <TableCell>192.168.1.105</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      Details
                    </Button>
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>Mar 7, 2025 08:15:42</TableCell>
                  <TableCell>sarah.j@company.com</TableCell>
                  <TableCell>
                    <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Login</Badge>
                  </TableCell>
                  <TableCell>User login successful</TableCell>
                  <TableCell>192.168.1.120</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      Details
                    </Button>
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>Mar 7, 2025 07:58:33</TableCell>
                  <TableCell>admin@company.com</TableCell>
                  <TableCell>
                    <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">User Management</Badge>
                  </TableCell>
                  <TableCell>Created new user account for Alex Thompson</TableCell>
                  <TableCell>192.168.1.105</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      Details
                    </Button>
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>Mar 7, 2025 07:45:19</TableCell>
                  <TableCell>admin@company.com</TableCell>
                  <TableCell>
                    <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Permission Revoke</Badge>
                  </TableCell>
                  <TableCell>Revoked Financial Portal access from James Wilson</TableCell>
                  <TableCell>192.168.1.105</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      Details
                    </Button>
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>Mar 7, 2025 07:30:05</TableCell>
                  <TableCell>system</TableCell>
                  <TableCell>
                    <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">System</Badge>
                  </TableCell>
                  <TableCell>Automatic security patch applied</TableCell>
                  <TableCell>127.0.0.1</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      Details
                    </Button>
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>Mar 7, 2025 07:15:42</TableCell>
                  <TableCell>mike.smith@company.com</TableCell>
                  <TableCell>
                    <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Login</Badge>
                  </TableCell>
                  <TableCell>User login successful</TableCell>
                  <TableCell>192.168.1.130</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      Details
                    </Button>
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>Mar 7, 2025 07:05:18</TableCell>
                  <TableCell>unknown</TableCell>
                  <TableCell>
                    <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Failed Login</Badge>
                  </TableCell>
                  <TableCell>Failed login attempt for user lisa.b@company.com</TableCell>
                  <TableCell>203.0.113.42</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      Details
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          <div className="flex items-center justify-between mt-6">
            <div className="text-sm text-muted-foreground">Showing 7 of 1,253 log entries</div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="icon">
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" className="h-8 w-8">
                1
              </Button>
              <Button variant="outline" size="sm" className="h-8 w-8">
                2
              </Button>
              <Button variant="outline" size="sm" className="h-8 w-8">
                3
              </Button>
              <Button variant="outline" size="icon">
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

