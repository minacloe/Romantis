import type { Metadata } from "next"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Clock, CheckCircle, XCircle } from "lucide-react"

export const metadata: Metadata = {
  title: "Pending Requests | Corporate Permission Management",
  description: "View and manage your pending access requests",
}

export default function PendingRequests() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">My Requests</h1>
        <p className="text-gray-600 mt-2">Track and manage your access requests</p>
      </div>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="approved">Approved</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
          <TabsTrigger value="all">All Requests</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-6">
          <div className="space-y-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-yellow-100 p-3 rounded-full">
                      <Clock className="h-6 w-6 text-yellow-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">HR System Access</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline">Read Only</Badge>
                        <span className="text-sm text-muted-foreground">Requested on Mar 5, 2025</span>
                      </div>
                      <p className="text-sm mt-2">Need access to view employee records for my team.</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 md:items-end">
                    <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                      Pending Manager Approval
                    </Badge>
                    <div className="flex gap-2 mt-2">
                      <Button variant="outline" size="sm">
                        Cancel Request
                      </Button>
                      <Button size="sm">Track Status</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-yellow-100 p-3 rounded-full">
                      <Clock className="h-6 w-6 text-yellow-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">Financial System</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline">Edit Access</Badge>
                        <span className="text-sm text-muted-foreground">Requested on Mar 3, 2025</span>
                      </div>
                      <p className="text-sm mt-2">Need to update budget information for Q2 planning.</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 md:items-end">
                    <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Under Review</Badge>
                    <div className="flex gap-2 mt-2">
                      <Button variant="outline" size="sm">
                        Cancel Request
                      </Button>
                      <Button size="sm">Track Status</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="approved" className="mt-6">
          <div className="space-y-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-green-100 p-3 rounded-full">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">Project Management Tool</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline">Full Access</Badge>
                        <span className="text-sm text-muted-foreground">Approved on Mar 2, 2025</span>
                      </div>
                      <p className="text-sm mt-2">Access granted for managing team projects and tasks.</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 md:items-end">
                    <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>
                    <Button variant="outline" size="sm" className="mt-2">
                      View Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-green-100 p-3 rounded-full">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">Document Management System</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline">Read Only</Badge>
                        <span className="text-sm text-muted-foreground">Approved on Feb 28, 2025</span>
                      </div>
                      <p className="text-sm mt-2">Access to view company policies and procedures.</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 md:items-end">
                    <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>
                    <Button variant="outline" size="sm" className="mt-2">
                      View Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="rejected" className="mt-6">
          <div className="space-y-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-red-100 p-3 rounded-full">
                      <XCircle className="h-6 w-6 text-red-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">Customer Database</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline">Full Access</Badge>
                        <span className="text-sm text-muted-foreground">Rejected on Feb 25, 2025</span>
                      </div>
                      <p className="text-sm mt-2">Request for full access to customer database.</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 md:items-end">
                    <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>
                    <div className="flex gap-2 mt-2">
                      <Button variant="outline" size="sm">
                        View Reason
                      </Button>
                      <Button size="sm">Resubmit</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="all" className="mt-6">
          <div className="space-y-4">
            {/* This would include all requests from the other tabs */}
            <p className="text-muted-foreground mb-4">Showing all requests (5)</p>

            {/* Pending Requests */}
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-yellow-100 p-3 rounded-full">
                      <Clock className="h-6 w-6 text-yellow-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">HR System Access</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline">Read Only</Badge>
                        <span className="text-sm text-muted-foreground">Requested on Mar 5, 2025</span>
                      </div>
                    </div>
                  </div>
                  <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Pending</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Approved Requests */}
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-green-100 p-3 rounded-full">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">Project Management Tool</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline">Full Access</Badge>
                        <span className="text-sm text-muted-foreground">Approved on Mar 2, 2025</span>
                      </div>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Rejected Request */}
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-red-100 p-3 rounded-full">
                      <XCircle className="h-6 w-6 text-red-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">Customer Database</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline">Full Access</Badge>
                        <span className="text-sm text-muted-foreground">Rejected on Feb 25, 2025</span>
                      </div>
                    </div>
                  </div>
                  <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

