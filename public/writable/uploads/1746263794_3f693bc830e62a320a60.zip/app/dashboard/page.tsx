import type { Metadata } from "next"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { CheckCircle, Clock, Lock } from "lucide-react"

export const metadata: Metadata = {
  title: "User Dashboard | Corporate Permission Management",
  description: "User dashboard for corporate permission management",
}

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-2">Welcome back, John Doe</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Active Permissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">7</div>
            <p className="text-sm text-muted-foreground mt-1">Across 3 systems</p>
            <Button variant="outline" className="w-full mt-4">
              View Details
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Pending Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">2</div>
            <p className="text-sm text-muted-foreground mt-1">Awaiting approval</p>
            <Button variant="outline" className="w-full mt-4">
              View Requests
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">5</div>
            <p className="text-sm text-muted-foreground mt-1">Actions in last 7 days</p>
            <Button variant="outline" className="w-full mt-4">
              View Activity
            </Button>
          </CardContent>
        </Card>
      </div>

      <h2 className="text-xl font-semibold mt-8 mb-4">My Permissions</h2>
      <div className="space-y-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <Lock className="h-4 w-4 text-primary" />
                  <h3 className="font-medium">CRM System</h3>
                  <Badge className="ml-2">Full Access</Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">Customer data, sales reports, analytics</p>
              </div>
              <Button variant="ghost" size="sm">
                Manage
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <Lock className="h-4 w-4 text-primary" />
                  <h3 className="font-medium">Financial Portal</h3>
                  <Badge className="ml-2">Read Only</Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">Budget reports, expense tracking</p>
              </div>
              <Button variant="ghost" size="sm">
                Manage
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <Lock className="h-4 w-4 text-primary" />
                  <h3 className="font-medium">Document Management</h3>
                  <Badge className="ml-2">Edit Access</Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">Corporate documents, templates, policies</p>
              </div>
              <Button variant="ghost" size="sm">
                Manage
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <h2 className="text-xl font-semibold mt-8 mb-4">Recent Requests</h2>
      <div className="space-y-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-yellow-100 p-2 rounded-full">
                  <Clock className="h-5 w-5 text-yellow-600" />
                </div>
                <div>
                  <h3 className="font-medium">HR System Access</h3>
                  <p className="text-sm text-muted-foreground">Requested on Mar 5, 2025</p>
                </div>
              </div>
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 hover:bg-yellow-50">
                Pending
              </Badge>
            </div>
            <Progress value={50} className="h-2 mt-4" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-green-100 p-2 rounded-full">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium">Project Management Tool</h3>
                  <p className="text-sm text-muted-foreground">Approved on Mar 2, 2025</p>
                </div>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50">
                Approved
              </Badge>
            </div>
            <Progress value={100} className="h-2 mt-4" />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

