import type { Metadata } from "next"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"

export const metadata: Metadata = {
  title: "Request Access | Corporate Permission Management",
  description: "Request access to corporate systems",
}

export default function RequestAccess() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Request Access</h1>
        <p className="text-gray-600 mt-2">Request access to corporate systems and resources</p>
      </div>

      <Card className="max-w-3xl">
        <CardHeader>
          <CardTitle>New Access Request</CardTitle>
          <CardDescription>Fill out the form below to request access to a system or resource.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="system">System or Resource</Label>
              <Select>
                <SelectTrigger id="system">
                  <SelectValue placeholder="Select a system" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="crm">CRM System</SelectItem>
                  <SelectItem value="hr">HR Portal</SelectItem>
                  <SelectItem value="finance">Financial System</SelectItem>
                  <SelectItem value="docs">Document Management</SelectItem>
                  <SelectItem value="project">Project Management</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Access Level</Label>
              <RadioGroup defaultValue="read" className="mt-2">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="read" id="read" />
                  <Label htmlFor="read" className="font-normal">
                    Read Only
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="edit" id="edit" />
                  <Label htmlFor="edit" className="font-normal">
                    Edit Access
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="full" id="full" />
                  <Label htmlFor="full" className="font-normal">
                    Full Access
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label htmlFor="reason">Business Justification</Label>
              <Textarea
                id="reason"
                placeholder="Explain why you need access to this system..."
                className="mt-1"
                rows={4}
              />
            </div>

            <div>
              <Label htmlFor="duration">Duration</Label>
              <Select>
                <SelectTrigger id="duration">
                  <SelectValue placeholder="Select duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="temp">Temporary (30 days)</SelectItem>
                  <SelectItem value="project">Project-based</SelectItem>
                  <SelectItem value="permanent">Permanent</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="manager">Manager Approval</Label>
              <Input id="manager" placeholder="Enter your manager's email" className="mt-1" />
            </div>

            <div className="flex items-start space-x-2 pt-2">
              <Checkbox id="terms" />
              <div className="grid gap-1.5 leading-none">
                <Label
                  htmlFor="terms"
                  className="text-sm font-normal leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  I confirm that I have read and agree to the Acceptable Use Policy
                </Label>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">Cancel</Button>
          <Button>Submit Request</Button>
        </CardFooter>
      </Card>
    </div>
  )
}

