"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Home, FileText, Clock, User, LogOut, Menu, X } from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"

interface NavItemProps {
  href: string
  icon: React.ReactNode
  label: string
  isActive: boolean
  onClick?: () => void
}

function NavItem({ href, icon, label, isActive, onClick }: NavItemProps) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-3 px-3 py-2 rounded-md transition-colors",
        isActive ? "bg-primary text-primary-foreground" : "hover:bg-secondary text-gray-700 hover:text-gray-900",
      )}
      onClick={onClick}
    >
      {icon}
      <span>{label}</span>
    </Link>
  )
}

export default function UserLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
  }

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false)
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
      {/* Mobile Header */}
      <div className="md:hidden bg-white p-4 flex items-center justify-between shadow-sm">
        <h1 className="text-xl font-bold">Permission Management</h1>
        <Button variant="ghost" size="icon" onClick={toggleMobileMenu}>
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </Button>
      </div>

      {/* Sidebar - Mobile (Overlay) */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 bg-black/50 z-40" onClick={closeMobileMenu}>
          <div className="w-64 h-full bg-white p-4 shadow-lg" onClick={(e) => e.stopPropagation()}>
            <div className="flex flex-col h-full">
              <div className="mb-6">
                <h2 className="text-xl font-bold mb-6">User Portal</h2>
                <div className="space-y-1">
                  <NavItem
                    href="/dashboard"
                    icon={<Home size={20} />}
                    label="Dashboard"
                    isActive={pathname === "/dashboard"}
                    onClick={closeMobileMenu}
                  />
                  <NavItem
                    href="/dashboard/request-access"
                    icon={<FileText size={20} />}
                    label="Request Access"
                    isActive={pathname === "/dashboard/request-access"}
                    onClick={closeMobileMenu}
                  />
                  <NavItem
                    href="/dashboard/pending-requests"
                    icon={<Clock size={20} />}
                    label="Pending Requests"
                    isActive={pathname === "/dashboard/pending-requests"}
                    onClick={closeMobileMenu}
                  />
                  <NavItem
                    href="/dashboard/profile"
                    icon={<User size={20} />}
                    label="My Profile"
                    isActive={pathname === "/dashboard/profile"}
                    onClick={closeMobileMenu}
                  />
                </div>
              </div>
              <div className="mt-auto">
                <Button asChild variant="outline" className="w-full">
                  <Link href="/" onClick={closeMobileMenu}>
                    <LogOut size={20} className="mr-2" />
                    Logout
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar - Desktop */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 bg-white border-r">
        <div className="flex flex-col h-full p-4">
          <div className="mb-6">
            <h2 className="text-xl font-bold mb-6">User Portal</h2>
            <div className="space-y-1">
              <NavItem
                href="/dashboard"
                icon={<Home size={20} />}
                label="Dashboard"
                isActive={pathname === "/dashboard"}
              />
              <NavItem
                href="/dashboard/request-access"
                icon={<FileText size={20} />}
                label="Request Access"
                isActive={pathname === "/dashboard/request-access"}
              />
              <NavItem
                href="/dashboard/pending-requests"
                icon={<Clock size={20} />}
                label="Pending Requests"
                isActive={pathname === "/dashboard/pending-requests"}
              />
              <NavItem
                href="/dashboard/profile"
                icon={<User size={20} />}
                label="My Profile"
                isActive={pathname === "/dashboard/profile"}
              />
            </div>
          </div>
          <div className="mt-auto">
            <Button asChild variant="outline" className="w-full">
              <Link href="/">
                <LogOut size={20} className="mr-2" />
                Logout
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 p-4 md:p-6">{children}</main>
    </div>
  )
}

