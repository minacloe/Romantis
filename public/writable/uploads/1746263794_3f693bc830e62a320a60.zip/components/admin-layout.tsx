"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Home, Users, FileCheck, Settings, ClipboardList, LogOut, Menu, X } from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"

interface NavItemProps {
  href: string
  icon: React.ReactNode
  label: string
  isActive: boolean
  onClick?: () => void
}

function NavItem({ href, icon, label, isActive, onClick }: NavItemProps) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-3 px-3 py-2 rounded-md transition-colors",
        isActive ? "bg-primary text-primary-foreground" : "hover:bg-secondary text-gray-700 hover:text-gray-900",
      )}
      onClick={onClick}
    >
      {icon}
      <span>{label}</span>
    </Link>
  )
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
  }

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false)
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
      {/* Mobile Header */}
      <div className="md:hidden bg-white p-4 flex items-center justify-between shadow-sm">
        <h1 className="text-xl font-bold">Admin Portal</h1>
        <Button variant="ghost" size="icon" onClick={toggleMobileMenu}>
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </Button>
      </div>

      {/* Sidebar - Mobile (Overlay) */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 bg-black/50 z-40" onClick={closeMobileMenu}>
          <div className="w-64 h-full bg-white p-4 shadow-lg" onClick={(e) => e.stopPropagation()}>
            <div className="flex flex-col h-full">
              <div className="mb-6">
                <h2 className="text-xl font-bold mb-6">Admin Portal</h2>
                <div className="space-y-1">
                  <NavItem
                    href="/admin/dashboard"
                    icon={<Home size={20} />}
                    label="Dashboard"
                    isActive={pathname === "/admin/dashboard"}
                    onClick={closeMobileMenu}
                  />
                  <NavItem
                    href="/admin/users"
                    icon={<Users size={20} />}
                    label="User Management"
                    isActive={pathname === "/admin/users"}
                    onClick={closeMobileMenu}
                  />
                  <NavItem
                    href="/admin/requests"
                    icon={<FileCheck size={20} />}
                    label="Permission Requests"
                    isActive={pathname === "/admin/requests"}
                    onClick={closeMobileMenu}
                  />
                  <NavItem
                    href="/admin/settings"
                    icon={<Settings size={20} />}
                    label="System Settings"
                    isActive={pathname === "/admin/settings"}
                    onClick={closeMobileMenu}
                  />
                  <NavItem
                    href="/admin/audit-logs"
                    icon={<ClipboardList size={20} />}
                    label="Audit Logs"
                    isActive={pathname === "/admin/audit-logs"}
                    onClick={closeMobileMenu}
                  />
                </div>
              </div>
              <div className="mt-auto">
                <Button asChild variant="outline" className="w-full">
                  <Link href="/" onClick={closeMobileMenu}>
                    <LogOut size={20} className="mr-2" />
                    Logout
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar - Desktop */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 bg-white border-r">
        <div className="flex flex-col h-full p-4">
          <div className="mb-6">
            <h2 className="text-xl font-bold mb-6">Admin Portal</h2>
            <div className="space-y-1">
              <NavItem
                href="/admin/dashboard"
                icon={<Home size={20} />}
                label="Dashboard"
                isActive={pathname === "/admin/dashboard"}
              />
              <NavItem
                href="/admin/users"
                icon={<Users size={20} />}
                label="User Management"
                isActive={pathname === "/admin/users"}
              />
              <NavItem
                href="/admin/requests"
                icon={<FileCheck size={20} />}
                label="Permission Requests"
                isActive={pathname === "/admin/requests"}
              />
              <NavItem
                href="/admin/settings"
                icon={<Settings size={20} />}
                label="System Settings"
                isActive={pathname === "/admin/settings"}
              />
              <NavItem
                href="/admin/audit-logs"
                icon={<ClipboardList size={20} />}
                label="Audit Logs"
                isActive={pathname === "/admin/audit-logs"}
              />
            </div>
          </div>
          <div className="mt-auto">
            <Button asChild variant="outline" className="w-full">
              <Link href="/">
                <LogOut size={20} className="mr-2" />
                Logout
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 p-4 md:p-6">{children}</main>
    </div>
  )
}

