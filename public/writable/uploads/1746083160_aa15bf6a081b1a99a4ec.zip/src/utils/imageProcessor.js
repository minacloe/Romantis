const tf = require('@tensorflow/tfjs-node');
const fs = require('fs');

const processImage = async (filePath) => {
    try {
        const imageBuffer = fs.readFileSync(filePath);

        // Decode, resize, normalize
        const tensor = tf.node.decodeImage(imageBuffer, 3)
            .resizeNearestNeighbor([224, 224]) // Resize ke ukuran model
            .toFloat()
            .div(tf.scalar(255)) // Normalisasi ke rentang [0, 1]
            .expandDims(); // Tambahkan dimensi batch

        return tensor;
    } catch (error) {
        throw new Error('Image processing failed: ' + error.message);
    }
};

module.exports = { processImage };
