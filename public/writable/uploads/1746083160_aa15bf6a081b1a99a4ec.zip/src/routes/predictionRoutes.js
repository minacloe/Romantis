const { predict, getHistories } = require('../controllers/predictionController');

const predictionRoutes = {
    name: 'predictionRoutes',
    register: async (server) => {
        server.route([
            {
                method: 'POST',
                path: '/predict',
                options: {
                    payload: {
                        output: 'stream', // Data dikirim sebagai stream
                        parse: true, // Data multipart akan diparsing
                        allow: 'multipart/form-data', // Hanya tipe multipart/form-data yang diperbolehkan
                        maxBytes: 1000000, // Batas ukuran payload 1MB
                        multipart: true, // Parsing multipart diaktifkan
                    },
                },
                handler: async (request, h) => {
                    try {
                        return await predict(request, h); // Memanggil fungsi prediksi
                    } catch (err) {
                        // Menangani error payload terlalu besar (413)
                        if (err.output && err.output.statusCode === 413) {
                            return h.response({
                                status: 'fail',
                                message: 'Payload content length greater than maximum allowed: 1000000',
                            }).code(413);
                        }
                        throw err; // Meneruskan error lainnya
                    }
                },
            },
            {
                method: 'GET',
                path: '/predict/histories',
                handler: getHistories, // Mengambil riwayat prediksi
            },
        ]);
    },
};

module.exports = predictionRoutes;
