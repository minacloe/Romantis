const admin = require('firebase-admin');
const serviceAccount = require('../../src/config/submissionmlgc-nurminatihk-firebase-adminsdk-sn68p-d65a9f8425.json');

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

module.exports = { db };
