const Hapi = require('@hapi/hapi');
const predictionRoutes = require('./routes/predictionRoutes');
const { loadModel } = require('./controllers/predictionController');

const init = async () => {
    const server = Hapi.server({
        port: process.env.PORT || 8080, // Menggunakan port 8080
        host: '0.0.0.0', // Agar dapat diakses dari luar Cloud Run
        routes: {
            cors: {
                origin: ['https://submissionmlgc-nurminatihk.et.r.appspot.com'], // URL frontend Anda
                headers: ['Accept', 'Content-Type'], // Header yang diizinkan
                exposedHeaders: ['Accept', 'Content-Type'], // Header yang dapat diakses di frontend
                additionalExposedHeaders: ['Authorization'], // Jika ada token atau header tambahan
                credentials: true, // Jika menggunakan cookies atau sesi
            },
        },
    });

    // Route sederhana untuk memeriksa status server
    server.route({
        method: 'GET',
        path: '/',
        handler: () => {
            console.log('Debug: Root route accessed');
            return 'Backend is running successfully!';
        },
    });

    // Penanganan error umum untuk seluruh server
    server.ext('onPreResponse', (request, h) => {
        const response = request.response;
        if (response.isBoom) {
            if (response.output.statusCode === 413) {
                console.error('Error 413: Payload Too Large');
                return h.response({
                    status: 'fail',
                    message: 'Payload content length greater than maximum allowed: 1000000',
                }).code(413);
            }
            console.error('Error Response:', response.output.payload);
        }
        return h.continue;
    });

    // Load TensorFlow model sebelum server berjalan
    await loadModel();

    // Register routes dari predictionRoutes
    await server.register(predictionRoutes);

    // Jalankan server
    await server.start();
    console.log(`✅ Backend server is running on ${server.info.uri}`);
};

init().catch((error) => {
    console.error('❌ Server initialization failed:', error);
    process.exit(1); // Keluar jika server gagal dijalankan
});
