const { v4: uuidv4 } = require('uuid');
const { db } = require('../config/firebase');
const fs = require('fs');
const path = require('path');
const tf = require('@tensorflow/tfjs-node');

const MODEL_URL = 'https://storage.googleapis.com/mlgc-storage-dicoding-nurmi/model.json';
let model;

// Load TensorFlow model
const loadModel = async () => {
    try {
        model = await tf.loadGraphModel(MODEL_URL);
        console.log('✅ Model loaded successfully');
    } catch (error) {
        console.error('❌ Failed to load model:', error);
        process.exit(1);
    }
};

const predict = async (request, h) => {
    let tempFilePath;
    try {
        const file = request.payload.image;

        if (!file) {
            console.error('❌ No image provided');
            return h.response({
                status: 'fail',
                message: 'Image is required',
            }).code(400);
        }

        // Simpan file sementara
        const uploadsDir = path.resolve(__dirname, '../../uploads');
        if (!fs.existsSync(uploadsDir)) {
            fs.mkdirSync(uploadsDir, { recursive: true });
        }

        tempFilePath = path.join(uploadsDir, uuidv4() + path.extname(file.hapi.filename));
        const writeStream = fs.createWriteStream(tempFilePath);
        file.pipe(writeStream);

        await new Promise((resolve, reject) => {
            writeStream.on('finish', resolve);
            writeStream.on('error', reject);
        });

        console.log(`✅ File saved temporarily at ${tempFilePath}`);

        // Membaca file gambar sebagai buffer
        const imageBuffer = fs.readFileSync(tempFilePath);

        // Proses gambar menggunakan TensorFlow
        let tensor;
        try {
            tensor = tf.node
                .decodeJpeg(imageBuffer)
                .resizeNearestNeighbor([224, 224])
                .expandDims()
                .toFloat();
        } catch (error) {
            console.error('❌ Error processing image:', error.message);
            return h.response({
                status: 'fail',
                message: 'Terjadi kesalahan dalam melakukan prediksi',
            }).code(400);
        }

        // Prediksi dengan model
        let predictions;
        try {
            predictions = await model.predict(tensor).data();
        } catch (error) {
            console.error('❌ Error during model prediction:', error.message);
            return h.response({
                status: 'fail',
                message: 'Terjadi kesalahan dalam melakukan prediksi',
            }).code(400);
        }

        // Logging nilai prediksi
        console.log('🔍 Predictions:', predictions);

        // Evaluasi berdasarkan threshold
        const THRESHOLD = 0.5;
        const result = predictions[0] > THRESHOLD ? 'Cancer' : 'Non-cancer';
        const suggestion = result === 'Cancer' 
            ? 'Segera periksa ke dokter!' 
            : 'Penyakit kanker tidak terdeteksi.';
        const createdAt = new Date().toISOString();
        const id = uuidv4();

        console.log(`Confidence: ${predictions[0]}, Result: ${result}`);

        // Simpan hasil ke Firestore
        await db.collection('predictions').doc(id).set({
            id,
            result,
            suggestion,
            createdAt,
        });

        console.log(`✅ Prediction saved to Firestore with ID: ${id}`);
        return h.response({
            status: 'success',
            message: 'Model is predicted successfully',
            data: { id, result, suggestion, createdAt },
        }).code(201);
    } catch (error) {
        console.error('❌ Prediction error:', error.message);
        return h.response({
            status: 'fail',
            message: 'Internal Server Error',
        }).code(500);
    } finally {
        // Hapus file sementara
        if (tempFilePath && fs.existsSync(tempFilePath)) {
            fs.unlinkSync(tempFilePath);
        }
    }
};


const getHistories = async (_request, h) => {
    try {
        const snapshot = await db.collection('predictions').get();

        if (snapshot.empty) {
            console.log('Tidak ada riwayat prediksi ditemukan');
            return h.response({
                status: 'success',
                data: [],
            }).code(200);
        }

        const histories = snapshot.docs.map((doc) => {
            const data = doc.data();
            return {
                id: data.id,
                history: {
                    id: data.id,
                    result: data.result,
                    createdAt: data.createdAt,
                    suggestion: data.suggestion,
                },
            };
        });

        console.log(`✅ Berhasil mengambil ${histories.length} riwayat prediksi`);
        return h.response({
            status: 'success',
            data: histories,
        }).code(200);
    } catch (error) {
        console.error('❌ Error fetching histories:', error);
        return h.response({
            status: 'fail',
            message: 'Internal Server Error',
        }).code(500);
    }
};

module.exports = { loadModel, predict, getHistories };
